<template>
    <div class="container text-start my-3">
        <h1 id="title">Política de Privacidad</h1>

        <section>
            <h2>1. Responsable del Tratamiento</h2>
            <p>El responsable del tratamiento de sus datos personales es <strong>Import-Export Teis, S.L.</strong>, con
                domicilio en Avenida de Galicia, 101 , 45, 36216 Vigo, España, y CIF B-12345678. Puede ponerse en
                contacto con nosotros a través de:</p>
            <ul>
                <li>Correo electrónico: <a>info@importexportteis.com</a></li>
                <li>Teléfono: +34 986 111 111</li>
            </ul>
        </section>

        <section>
            <h2>2. Datos que Recogemos</h2>
            <p>Recopilamos datos personales que usted nos proporciona directamente al utilizar nuestro sitio web o
                nuestros servicios. Estos datos incluyen:</p>
            <ul>
                <li>Información de contacto: nombre, correo electrónico, teléfono.</li>
                <li>Datos necesarios para realizar transacciones o pedidos: dirección, detalles de pago.</li>
                <li>Información adicional que nos facilite voluntariamente a través de formularios o correos
                    electrónicos.</li>
            </ul>
        </section>

        <section>
            <h2>3. Finalidad del Tratamiento</h2>
            <p>Tratamos los datos personales para las siguientes finalidades:</p>
            <ul>
                <li>Responder a consultas realizadas a través del sitio web.</li>
                <li>Gestionar pedidos y envíos de productos o servicios.</li>
                <li>Enviar comunicaciones comerciales relacionadas con nuestros productos o servicios, previo
                    consentimiento expreso.</li>
                <li>Cumplir con obligaciones legales.</li>
            </ul>
        </section>

        <section>
            <h2>4. Base Jurídica del Tratamiento</h2>
            <p>El tratamiento de sus datos personales se basa en:</p>
            <ul>
                <li>Su consentimiento para el envío de formularios de contacto o suscripción.</li>
                <li>La ejecución de un contrato en caso de pedidos.</li>
                <li>El cumplimiento de obligaciones legales.</li>
            </ul>
        </section>

        <section>
            <h2>5. Destinatarios de los Datos</h2>
            <p>Sus datos personales no serán compartidos con terceros, excepto en los casos necesarios para cumplir con
                una obligación legal o para ejecutar un contrato (por ejemplo, servicios de transporte).</p>
        </section>

        <section>
            <h2>6. Conservación de los Datos</h2>
            <p>Conservaremos sus datos personales mientras sean necesarios para cumplir con las finalidades descritas.
                Cuando ya no sean necesarios, se eliminarán de forma segura.</p>
        </section>

        <section>
            <h2>7. Derechos del Usuario</h2>
            <p>Usted tiene derecho a:</p>
            <ul>
                <li>Acceder a sus datos personales.</li>
                <li>Rectificar datos inexactos o incompletos.</li>
                <li>Solicitar la supresión de sus datos cuando ya no sean necesarios.</li>
                <li>Limitar el tratamiento de sus datos en determinadas circunstancias.</li>
                <li>Oponerse al tratamiento de sus datos para fines específicos.</li>
                <li>Solicitar la portabilidad de sus datos.</li>
            </ul>
            <p>Para ejercer estos derechos, puede enviar una solicitud a <a>info@importexportteis.com</a>, adjuntando una copia de su
                documento de identidad.</p>
        </section>

        <section>
            <h2>8. Seguridad de los Datos</h2>
            <p>Implementamos medidas técnicas y organizativas para garantizar la seguridad de sus datos personales y
                protegerlos frente a accesos no autorizados, pérdida o destrucción.</p>
        </section>

        <section>
            <h2>9. Cambios en la Política de Privacidad</h2>
            <p>Nos reservamos el derecho a actualizar esta Política de Privacidad en cualquier momento. La fecha de la
                última modificación se indicará al final del documento.</p>
        </section>

        <section>
            <h2>10. Contacto</h2>
            <p>Si tiene alguna pregunta o desea más información sobre nuestra Política de Privacidad, no dude en
                contactarnos en <a>info@importexportteis.com</a>.</p>
        </section>
        <p>Para más información, consulte nuestro <router-link to="/avisos-legales">Aviso legal</router-link>.</p>
        <strong>Fecha de última actualización: 12/09/2024</strong>
    </div>
</template>
<script>
export default {
    name: "politicaPrivacidad",
    components: {}
}
</script>

<style scoped>
    div {
        font-size: 10px;
        text-align: justify;
    }
    h1 {
        font-size: 13px;
    }
    h2 {
        font-size: 11px;
    }
</style>