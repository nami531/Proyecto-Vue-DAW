<template>
    <p>Página de Contacto</p>
</template>

<script>

    export default {
        name : "TablaContacto",
        components : {
            
        }
    }
</script>

<style></style>